import React from 'react';
import { UserProvider } from './contexts/UserContext';
import UserForm from './components/UserForm';
import UserList from './components/UserList';

function App() {
  return (
    <UserProvider>
      <div className="container py-4">
        <header className="text-center mb-5">
          <h1 className="display-4 fw-bold">User Management System</h1>
          <p className="lead">Full CRUD application for managing users</p>
        </header>
        
        <main>
          <UserForm />
          <UserList />
        </main>
        
        <footer className="mt-5 text-center text-muted">
          <p>© {new Date().getFullYear()} User Management System</p>
        </footer>
      </div>
    </UserProvider>
  );
}

export default App;