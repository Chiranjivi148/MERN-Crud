import React, { useContext } from 'react';
import { useUsers } from '../contexts/UserContext';
import UserItem from './UserItem';

const UserList = () => {
  const { users, loading, error } = useUsers();
  
  if (loading) {
    return (
      <div className="d-flex justify-content-center mt-5">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="alert alert-danger mt-4" role="alert">
        <strong>Error:</strong> {error}
      </div>
    );
  }
  
  if (users.length === 0) {
    return (
      <div className="card mt-4">
        <div className="card-body text-center">
          <h5 className="card-title">No Users Found</h5>
          <p className="card-text">Add your first user using the form above</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="card mt-4">
      <div className="card-body">
        <h2 className="card-title">User List</h2>
        
        <div className="table-responsive">
          <table className="table table-hover">
            <thead>
              <tr>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Age</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <UserItem key={user._id} user={user} />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default UserList;