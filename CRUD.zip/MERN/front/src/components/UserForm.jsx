import React, { useState, useContext } from 'react';
import { useUsers } from '../contexts/UserContext';

const UserForm = () => {
  const { currentUser, addUser, updateUser, clearCurrentUser } = useUsers();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    dob: ''
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Set form data when editing
  React.useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name,
        email: currentUser.email,
        dob: currentUser.dob.split('T')[0] // Format date for input
      });
    } else {
      setFormData({
        name: '',
        email: '',
        dob: ''
      });
    }
  }, [currentUser]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validate = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email address is invalid';
    }
    
    if (!formData.dob) {
      newErrors.dob = 'Date of birth is required';
    } else {
      const dobDate = new Date(formData.dob);
      const today = new Date();
      
      if (dobDate > today) {
        newErrors.dob = 'Date of birth cannot be in the future';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validate()) return;
    
    setIsSubmitting(true);
    
    try {
      if (currentUser) {
        await updateUser(currentUser._id, formData);
        clearCurrentUser();
      } else {
        await addUser(formData);
      }
      
      setFormData({
        name: '',
        email: '',
        dob: ''
      });
    } catch (error) {
      console.error('Error:', error);
      alert(`Error: ${error.message || 'Something went wrong'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    clearCurrentUser();
    setFormData({
      name: '',
      email: '',
      dob: ''
    });
  };

  return (
    <div className="card mb-4">
      <div className="card-body">
        <h2 className="card-title">
          {currentUser ? 'Edit User' : 'Add New User'}
        </h2>
        
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">Name</label>
            <input
              type="text"
              className={`form-control ${errors.name ? 'is-invalid' : ''}`}
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter full name"
            />
            {errors.name && <div className="invalid-feedback">{errors.name}</div>}
          </div>
          
          <div className="mb-3">
            <label htmlFor="email" className="form-label">Email</label>
            <input
              type="email"
              className={`form-control ${errors.email ? 'is-invalid' : ''}`}
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter email address"
            />
            {errors.email && <div className="invalid-feedback">{errors.email}</div>}
          </div>
          
          <div className="mb-3">
            <label htmlFor="dob" className="form-label">Date of Birth</label>
            <input
              type="date"
              className={`form-control ${errors.dob ? 'is-invalid' : ''}`}
              id="dob"
              name="dob"
              value={formData.dob}
              onChange={handleChange}
            />
            {errors.dob && <div className="invalid-feedback">{errors.dob}</div>}
          </div>
          
          <div className="d-flex gap-2">
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
              ) : currentUser ? (
                'Update User'
              ) : (
                'Add User'
              )}
            </button>
            
            {currentUser && (
              <button 
                type="button" 
                className="btn btn-outline-secondary"
                onClick={handleCancel}
                disabled={isSubmitting}
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default UserForm;