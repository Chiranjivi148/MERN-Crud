import React from 'react';
import AgeCalculator from './AgeCalculator';
import { useUsers } from '../contexts/UserContext';

const UserItem = ({ user }) => {
  const { setUserToEdit, deleteUser } = useUsers();
  
  const handleEdit = () => {
    setUserToEdit(user);
  };
  
  const handleDelete = async () => {
    if (window.confirm(`Are you sure you want to delete ${user.name}?`)) {
      try {
        await deleteUser(user._id);
      } catch (error) {
        console.error('Error deleting user:', error);
        alert(`Error: ${error.message || 'Failed to delete user'}`);
      }
    }
  };
  
  return (
    <tr>
      <td className="align-middle">{user.name}</td>
      <td className="align-middle">{user.email}</td>
      <td className="align-middle">
        <AgeCalculator dob={user.dob} />
      </td>
      <td className="align-middle">
        <div className="d-flex gap-2">
          <button 
            className="btn btn-sm btn-outline-primary"
            onClick={handleEdit}
          >
            Edit
          </button>
          <button 
            className="btn btn-sm btn-outline-danger"
            onClick={handleDelete}
          >
            Delete
          </button>
        </div>
      </td>
    </tr>
  );
};

export default UserItem;