import React, { createContext, useState, useEffect, useContext } from 'react';
import { userAPI } from '../services/api';

const UserContext = createContext();

export const useUsers = () => useContext(UserContext);

export const UserProvider = ({ children }) => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const data = await userAPI.getAll();
      setUsers(data);
      setError(null);
    } catch (err) {
      setError(err.message || 'Failed to fetch users');
    } finally {
      setLoading(false);
    }
  };

  const addUser = async (userData) => {
    try {
      const newUser = await userAPI.create(userData);
      setUsers([...users, newUser]);
      return newUser;
    } catch (err) {
      throw err;
    }
  };

  const updateUser = async (id, userData) => {
    try {
      const updatedUser = await userAPI.update(id, userData);
      setUsers(users.map(user => user._id === id ? updatedUser : user));
      return updatedUser;
    } catch (err) {
      throw err;
    }
  };

  const deleteUser = async (id) => {
    try {
      await userAPI.delete(id);
      setUsers(users.filter(user => user._id !== id));
    } catch (err) {
      throw err;
    }
  };

  const setUserToEdit = (user) => {
    setCurrentUser(user);
  };

  const clearCurrentUser = () => {
    setCurrentUser(null);
  };

  const value = {
    users,
    currentUser,
    loading,
    error,
    fetchUsers,
    addUser,
    updateUser,
    deleteUser,
    setUserToEdit,
    clearCurrentUser
  };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};